package com.example.lesson_5a;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.objects.LoginInfo;

public class ResultActivity extends Activity {

	private TextView txtResult;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_result);
	
	Intent intent = getIntent();
	LoginInfo logininfo = (LoginInfo)intent.getSerializableExtra(MainActivity.LOGIN_INFO);
	
	txtResult = (TextView)findViewById(R.id.txtResult);
	txtResult.setText(String.format(txtResult.getText().toString(),logininfo.getLogin()));
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.result, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
