package com.example.lesson_5a;

import com.example.objects.LoginInfo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {
	
	public static final String LOGIN_INFO = "com.example.login_info";

	private TextView txtLogin;
	private TextView txtPassword;
	
	private Button btnClear;
	private Button btnLogin;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		btnClear = (Button)findViewById(R.id.btnClear);
		btnLogin = (Button)findViewById(R.id.btnLogin);
		
		txtLogin = (TextView)findViewById(R.id.txtLogin);
		txtPassword = (TextView)findViewById(R.id.txtPassword);
	}

	public void buttonClick(View view) {
		if (view== btnLogin) {
			
			LoginInfo logininfo = new LoginInfo();
			logininfo.setLogin(txtLogin.getText().toString());
			logininfo.setPassword(txtPassword.getText().toString());
			
			Intent resultIntent = new Intent(this, ResultActivity.class);
			resultIntent.putExtra(LOGIN_INFO, logininfo);
			startActivity(resultIntent);
			
		
		}
	else if(view== btnClear) {
			txtLogin.setText("");
			txtPassword.setText("");
			txtLogin.requestFocus();
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
